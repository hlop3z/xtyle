declare const preact: any;
declare const xtyle: any;
declare const h: any;
declare const Fragment: any;
