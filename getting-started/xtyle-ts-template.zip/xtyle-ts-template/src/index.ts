import app from "./components/counter";

export default app;
