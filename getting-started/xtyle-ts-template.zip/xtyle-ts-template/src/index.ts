import App from "./base/layout";

export default { App };
