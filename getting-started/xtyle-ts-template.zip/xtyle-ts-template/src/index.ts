import app from "./components/app";

export default { app };
