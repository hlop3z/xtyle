export default {
  // Sizes
  header: "50px",
  footer: "50px",
  right: "185px",
  left: "185px",
  leftMini: "60px",
  rightMini: "60px",

  // Layers
  headerLayer: 2,
  footerLayer: 2,
  leftLayer: 1,
  rightLayer: 1,
};
