import App from "./components/app";

const app = preact.h(App);

preact.render(app, document.body);
