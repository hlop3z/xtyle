import app from "./components/counter";

preact.render(preact.h(app), document.body);
