/**
 * Footer.
 */
export default function Component() {
  return <Fragment>Footer</Fragment>;
}
