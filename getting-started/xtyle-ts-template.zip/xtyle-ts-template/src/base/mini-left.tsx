/**
 * Left Side (Mini).
 */
export default function Component() {
  return (
    <Fragment>
      <h3>Mini-Left</h3>
    </Fragment>
  );
}
