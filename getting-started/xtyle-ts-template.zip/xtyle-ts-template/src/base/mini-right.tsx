/**
 * Right Side (Mini).
 */
export default function Component() {
  return (
    <Fragment>
      <h3>Mini-Right</h3>
    </Fragment>
  );
}
