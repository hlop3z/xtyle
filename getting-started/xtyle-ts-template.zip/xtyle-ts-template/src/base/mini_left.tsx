/**
 * Left Side (Mini).
 */
export default function Component() {
  return (
    <Fragment>
      <h2>Sample Content</h2>
    </Fragment>
  );
}
