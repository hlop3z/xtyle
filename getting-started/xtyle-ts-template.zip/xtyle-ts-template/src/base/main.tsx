export default function Component() {
  /* View */
  return (
    <Fragment>
      {/* <!-- Router --> */}
      <xtyle.router.view />
    </Fragment>
  );
}
