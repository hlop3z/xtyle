/**
 * Right Side.
 */
export default function Component() {
  return (
    <Fragment>
      <h3>Right</h3>
    </Fragment>
  );
}
