/**
 * Left Side.
 */
export default function Component() {
  return (
    <Fragment>
      <h3>Left</h3>
    </Fragment>
  );
}
