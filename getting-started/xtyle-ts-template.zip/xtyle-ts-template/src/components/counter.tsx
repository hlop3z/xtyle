/**
 * My Custom Component.
 * @param {any} props - The props of the component.
 */
export default function Component(props: any) {
  return <h1>Hello World</h1>;
}
