import "./style.css";

/**
 * My Custom Component.
 * @param {any} props - The props of the component.
 */
export default function Component(props: any) {
  console.log(props);
  return (
    <Fragment>
      <header>
        <h1>Welcome to Xtyle</h1>
      </header>
      <main>
        <h2>Sample Content</h2>
        <p>This is a demonstration.</p>
        <xtyle.element
          class="button"
          x-tag="button"
          x-click={(e) => console.log(e)}
        >
          Click Me
        </xtyle.element>
      </main>
    </Fragment>
  );
}
