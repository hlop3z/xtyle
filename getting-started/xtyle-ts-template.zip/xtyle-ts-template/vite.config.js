// vite.config.js
import { resolve } from "path";
import { defineConfig } from "vite";
import babel from "vite-plugin-babel";

export default defineConfig({
  build: {
    lib: {
      entry: resolve(__dirname, "src/index.ts"),
      name: "App",
      fileName: (format) => `App.${format}.js`,
    },
  },
  plugins: [
    babel({
      presets: [
        [
          "@babel/preset-react",
          {
            runtime: "automatic",
          },
        ],
      ],
      plugins: [
        [
          "@babel/plugin-transform-react-jsx",
          {
            pragma: "CustomCreateElement", // Specify your desired JSX pragma function
          },
        ],
      ],
    }),
  ],
});
