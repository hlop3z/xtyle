/// <reference types="./node_modules/xtyle/index.d.ts" />

declare const preact: any;
declare const h: any;
