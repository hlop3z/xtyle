export default {
  demo: (self: any, props: any) => {
    console.log(self);
    console.log(props.xDemo);
  },
};
