# Xtyle Custom Library

## Install

```sh
npm install
```

## Dev

```sh
npm run dev
```

## Build

```sh
npm run build
```

## Create a Component (Element)

**Note:** Use "`kebab-case`" => `PascalCase`

```sh
npm run app:start my-component
```
