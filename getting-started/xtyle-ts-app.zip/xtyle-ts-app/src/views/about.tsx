/**
 * About Page.
 */
export default function View() {
  return (
    <div>
      <h1>About Page</h1>
    </div>
  );
}
