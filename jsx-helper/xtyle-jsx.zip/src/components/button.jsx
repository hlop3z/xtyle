export default xtyle.h({
  props: {
    text: {
      type: String,
      default: "Count is",
    },
  },
  data: {
    count: 0,
  },
  methods: {
    toggle() {
      this.count += 1;
    },
  },
  view() {
    return (
      <button x-on:click={this.toggle}>
        {this.text} {this.count.toString()}
      </button>
    );
  },
});
