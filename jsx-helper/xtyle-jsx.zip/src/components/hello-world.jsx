import Button from "./button";

export default xtyle.h({
  view() {
    return (
      <div>
        <h1>Xtyle | App</h1>
        {Button()}
      </div>
    );
  },
});
