import "./assets/style.css";
import HelloWorld from "./components/hello-world";

const helloWorld = HelloWorld();

helloWorld.mount("#app");
