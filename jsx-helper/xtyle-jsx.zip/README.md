# Getting Started

```sh
npm install
npm run dev
```
