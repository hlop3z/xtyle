window.x = function x(...args) {
  const [tag, attrs, ...children] = args;
  return [tag, attrs, children];
};
